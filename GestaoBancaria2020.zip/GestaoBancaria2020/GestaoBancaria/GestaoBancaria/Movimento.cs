﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GestaoBancaria
{
    class Movimento
    {
        String TipoMovimento;
        int IdCliente;
     
        public void Movimentos() {

            int mov1, mov2, soma = 0;
            Console.WriteLine("Introduza o 1 Movimento: ");
            mov1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Introduza o 2 Movimento:");
            mov2 = Convert.ToInt32(Console.ReadLine());
            for (int i = mov1; i <= mov2; i++)
            {
                Console.WriteLine("OS seus movimentos {0} ", i);
                soma += i;
            }
            Console.WriteLine("os seus movimentos sao: {0}", soma);
        }
    }
}

﻿using System;

namespace GestaoBancaria
{
    class Program
    {
        static void Main(string[] args)
        {
            int opcao = 0;
            do
            {
                Console.WriteLine("Gestão Bancaria da sua conta :");
                Console.WriteLine("\n");
                Console.WriteLine("1 - Login de Cliente");
                Console.WriteLine("2 - Consultar");
                Console.WriteLine("3 - Inserir/Alterar/eliminar");
                Console.WriteLine("4 - Ver Saldo");
                Console.WriteLine("2 - Sair");

                opcao = Convert.ToInt32(Console.ReadLine());
                Console.Clear();

                switch (opcao)
                {
                    case 1:
                        Entrar();


                        break;
                    case 2:

                        break;
                    case 3:
                        Inserir();
                        break;
                    case 4:

                        break;
                }
            } while (opcao !=2 );
            Console.WriteLine("obrigado");
                 {
                opcao = 1;
                      do
                {

                    Console.WriteLine("Gestão Bancaria da sua conta :");
                    //Console.WriteLine("\n");
                    //Console.WriteLine("1 - Login de Cliente");
                    Console.WriteLine("2 - Consultar");
                    Console.WriteLine("3 - Inserir/Alterar/eliminar");
                    Console.WriteLine("4 - Ver Saldo");
                    Console.WriteLine("0 - Sair");

                  


                    switch (opcao =1 )
                    {


                        case 2:

                            break;
                        case 3:
                            Inserir();
                            break;
                        case 4:

                            break;
                    }
                } while (opcao != 1);
            }


            //Console.WriteLine("Consulte os seus movimentos: ");
            //Movimento movimentar = new Movimento();

            //movimentar.Movimentos();


            static void Entrar()
            {
                Console.WriteLine("Introduza os seus Dados");
                int IdCliente, Senha;
                Console.WriteLine("Introduza o seu Id de Cliente");
                IdCliente = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Introduza a senha");
                Senha = Convert.ToInt32(Console.ReadLine());
                Console.Write(" Bem Vindo Cliente:  {0}\n", IdCliente);
            }
            static void Inserir()
            {
                Console.WriteLine("Introduza os seus Dados");
                int IdCartao, IdConta;
                Console.WriteLine("Introduza o seu Id Conta");
                IdConta = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Introduza o cartao associado a conta");
                IdCartao = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(" A sua conta {0} tem associada o cartao nº {1}", IdConta, IdCartao);
            }

        }

    }

}


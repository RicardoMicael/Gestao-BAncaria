﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GestaoBancaria
{
    class Cartao
    {
        int IdCartao, Senha, IdCliente;
        string DataValidade, TipoCartao;
    }
}

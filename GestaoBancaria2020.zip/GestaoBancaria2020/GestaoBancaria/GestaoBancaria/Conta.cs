﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GestaoBancaria
{
    class Conta
    {
        string NomeCliente;
        int IdConta, IdCartao;
        string TipoConta;
 
        public double GetIdConta()
        {
            return IdConta;
        }
        public void SetIdConta(int IdConta)
        {
            this.IdConta = IdConta;
        
        }
        public double GetIdCartao()
        {
            return IdCartao;
        }
        public void SetIdCartao(int IdConta)
        {
            this.IdCartao = IdCartao;

        }
        public string GetNomeCliente()
        {
            return NomeCliente;
        }
        public void SetNomeCliente(string NomeCliente)
        {
            this.NomeCliente = NomeCliente;

         }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GestaoBancaria
{
    class Banco
    {
        int NibConta, IdCartao;
        string informacaoConta;    
    }
}

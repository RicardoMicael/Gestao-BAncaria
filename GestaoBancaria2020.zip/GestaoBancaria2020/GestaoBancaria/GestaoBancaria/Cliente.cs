﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GestaoBancaria
{
    class Cliente
    {
        String NomeCliente, DataNascimento, DataConta;

   

       private int IdCliente, IdConta, Nif, IdCartao, Senha;

        public Cliente(int Idcliente, int senha)
        {
            this.IdCliente = IdCliente;
            this.Senha = senha;
            
        }

        public double GetIdCliente()
        {
            return IdCliente;
        }
        public void SetIdcliente(int Idcliente)
        {
            this.IdCliente = IdCliente;

        }
        public string GetNome()
        {
            return NomeCliente;
        }
        public void Get(string NomeCliente)
        {
            this.NomeCliente = NomeCliente;
        }







        //int AcederConta()
        // {
        //     Console.WriteLine("Introduza o seu Id de Cliente");
        //     IdCliente = Convert.ToInt32(Console.ReadLine());

        //     Console.WriteLine("Introduza a senha");
        //     Senha =Convert.ToInt32(Console.ReadLine());

        //     Console.WriteLine("Bem vindo Cliente {0}", IdCliente);
        ////    return IdCliente ;

        // }
    }
}

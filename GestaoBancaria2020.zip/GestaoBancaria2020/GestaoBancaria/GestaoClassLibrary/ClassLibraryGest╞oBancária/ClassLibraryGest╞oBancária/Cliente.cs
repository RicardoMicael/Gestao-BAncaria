﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestaoBancaria
{
    class Cliente
    {

        private int ID, NumCartao, NIF;
        private string Nome, DataN, DataC;

    }
}

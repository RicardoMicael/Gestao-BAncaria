﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestaoBancaria
{
    class Cartão
    {
        private int ID, PIN, IDC;
        private string DataV, Tipo;
        

    }
}

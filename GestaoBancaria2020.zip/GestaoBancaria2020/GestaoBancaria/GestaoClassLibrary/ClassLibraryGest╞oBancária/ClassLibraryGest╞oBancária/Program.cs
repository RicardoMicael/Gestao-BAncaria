﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryGestãoBancária
{
    public class Program
    {
        static void Main(string[] args)
        {
            int a = 1;
            while (a < 0 && a > 2)
            {
                Console.WriteLine("Bem vindo a Net Bank\nEscolha uma das seguintes opções:");
                Console.WriteLine("Login:1 \nSair:0");

                a = Convert.ToInt32(Console.ReadLine());
                Erro(a);
            }

            if (a == 0)
                return;
            else if (a == 1)
                login();

            Console.Clear();
        }

        static void login()
        {
            Console.Write("LOGIN\nId conta:");
            int ID = Convert.ToInt32(Console.ReadLine());

        }



        static int Erro(int erro)
        {
            if (erro == null)
                Console.WriteLine("Não foi inserido um valor, certifique-se que o inseriu corretamente");

            //if (erro == 1)
            //    Console.WriteLine("O valor inserido é inválido, certifique-se que o inseriu corretamente");
            //else if (erro == 2)
            //    Console.WriteLine("Não foi inserido um valor, certifique-se que o inseriu corretamente");
            return erro;
        }
    }
}

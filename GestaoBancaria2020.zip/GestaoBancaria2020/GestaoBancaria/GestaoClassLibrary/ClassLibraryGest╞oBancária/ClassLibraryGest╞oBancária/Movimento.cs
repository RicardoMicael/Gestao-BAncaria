﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryGestãoBancária
{
    public class Movimento
    {
        private string TMovimento;
        private double Valor;

        public void movimento(String Tmovimento, double Valor)
        {
            this.TMovimento = Tmovimento;
            this.Valor = Valor;
        }

        public void GetTmovimento(string Tmovimento)
        {
            this.TMovimento = Tmovimento;
        }
        public string SetTmovimento()
        {
            return TMovimento;
        }

        public override string ToString()
        {
            return TMovimento + "; " + Valor.ToString();
        }
    }
}
